


<!DOCTYPE html>
<html lang="en">
<head>
<?php require_once ("bootstrap.php"); ?>
<title> Marianela Mendoza - Rock Paper Scissors </title>

</head>


  <body>
  <div class="container">
  <h1>Welcome to Rock Paper Scissors</h1>
  <p><a href="login.php" style="background-color: rgb(255, 255, 255);">Please Log In</a><br></p>
  <p>
  Attempt to go to
  <a href="game.php">game.php</a> without logging in - it should fail with an error message.
  </p><p>
  <a href="sourceCode_asg8.zip" target="_blank">Source Code for this Application</a>
  </p>
  </div>

</body>
</html>
